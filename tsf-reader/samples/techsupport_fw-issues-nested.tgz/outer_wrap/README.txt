Nested synthetic TSF wrapper for parser tests.
