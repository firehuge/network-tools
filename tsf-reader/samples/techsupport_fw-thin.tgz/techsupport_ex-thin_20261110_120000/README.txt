Synthetic thin bundle with no tmp/cli techsupport file.
